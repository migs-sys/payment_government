---
name: StellarX Submission
about: Submit Proof of Payment for Government Services
title: "Proof of Payment for Government Services"
labels: stellarx, submission
assignees: ""
---

## Project

Proof of Payment for Government Services

## Idea Number

76

## Summary

Proof of Payment for Government Services gives operators a shared settlement score trail, signed wallet actions, and a Soroban-backed release path that can be audited from dashboard to ledger.

## Stellar Usage

- Stellar testnet
- Soroban contract
- Freighter wallet
- Stellar SDK
- XLM/USDC SAC references
